import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime

data = pd.read_csv('BreadBasket_DMS.csv')

data['hourly'] = pd.to_datetime(data['Date']).dt.to_period('H')
hourlyTransactionForItem = data[['hourly','Transaction', 'Item']].groupby(['hourly', 'Item'], as_index=False).count().sort_values(by='hourly')
hourlyTransactionForItem.set_index('hourly' ,inplace=True)

print(hourlyTransactionForItem.head(35))



def map_indexes_and_values(df, col):
    df_col = df[col].value_counts()
    x = df_col.index.tolist()
    y = df_col.values.tolist()
    return x, y

item,item_count =  map_indexes_and_values(hourlyTransactionForItem, 'Item')
plt.bar(item[:10], item_count[:10], color='b', label='Monday')
plt.xlabel('transactions per hour')
plt.ylabel('Number of Transactions')
plt.show()